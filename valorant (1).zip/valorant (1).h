#pragma once
#include <cstdint>
namespace VALORANT
{
	uintptr_t Module;
}